package com.example.clock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class ClockController {

	@Autowired
	private SpeakingClock speakingClock;
	
	
	
	
	
	@GetMapping(value = "/getTimes/{time}")
	   public ResponseEntity<Object> ShowWordsTime(@PathVariable("time") String hour) { 
		String result=""  ;
		 try {
			 if(hour.contains(":")) {
				 hour.trim().split(":");
				 String[] hours = hour.trim().split(":");

			        try {
			        	Integer.parseInt(hours[0]);
			        	  Integer.parseInt(hours[1]);
			        	        
						        }  catch (ArrayIndexOutOfBoundsException e) {
						            throw new TimeNotfoundException();
						        }
			        result= speakingClock.solve().toString();
			        return new ResponseEntity<>("Time is Display successfully : "+result, HttpStatus.OK);
			  	  
			 }
			 else {
				 throw new TimeNotfoundException();
			 }
	        } catch (NumberFormatException e) {
	            throw new TimeNotfoundException();
	        }
	   }
}
