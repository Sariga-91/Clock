package com.example.clock;

public class TimeNotfoundException extends RuntimeException {
	   private static final long serialVersionUID = 1L;
	   
	}
