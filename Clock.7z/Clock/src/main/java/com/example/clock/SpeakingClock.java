package com.example.clock;

import org.springframework.stereotype.Component;

@Component
public class SpeakingClock {

   

    private static final String[] Ten = {"","Ten", "Twenty ", "Thirty ", "Forty ", "Fifty "};

    private static final String[] One = {
    		   "Twelve Four",  "One ", "Two ", "Three ", "Four ", "Five ",
            "Six ", "Seven ", "Eight ", "Nine ","Ten", "Eleven ",
            "Twelve ", "Thirteen ", "Fourteen ", "Fifteen ",
            "Sixteen ", "Seventeen ", "Eighteen ", "Nineteen ","Twenty ",
            "Twenty One ","Twenty Two ","Twenty Three","Twenty Four"
    };

 
    ClockData colClockData=new ClockData();
    
    
    
   public SpeakingClock(){
    	
    }
    public SpeakingClock(String hour) {

        try {
            hour.trim().split(":");
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Please Enter the  24 hour format ");
        }

        String[] hours = hour.trim().split(":");

        try {
            Integer.parseInt(hours[0]);
            Integer.parseInt(hours[1]);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Please Enter the  24 hour format");
        }

        colClockData.hours = Integer.parseInt(hours[0]);
        colClockData.minutes = Integer.parseInt(hours[1]);
        colClockData.result = "";
    }

   
    public String solve() {

        String hourInWords = convertToWords(   colClockData.getHours(), colClockData.getMinutes());

        if (hourInWords.equals("")) {
            System.out.println("It was not possible to convert the hour passed to words");
        } else {
        	colClockData.setResult(hourInWords);
            printResult();
        }
		return hourInWords;
    }

   
    public String convertToWords(int hour, int minutes) {

        StringBuilder result = new StringBuilder();

        if (colClockData.getMinutes() == 0) {

            if (colClockData.getHours() == 12) {
                return result.append("It's Midday").toString();
            }

            if (colClockData.getHours() == 24) {
                return result.append("It's Midnight").toString();
            }

            result.append("It's ").append(One[hour % 24]).append("O'Clock");
            
         
        } else if (minutes % 10 == 0) {
            result.append("It's ").append(One[hour % 24]).append(Ten[minutes / 10]) ;
        } else if (minutes < 10 || minutes > 20) {
            result.append("It's ").append(One[hour % 24]).append(Ten[minutes / 10]).append(One[minutes % 10]);
        } else {
            result.append("It's ").append(One[hour % 24]).append(One[minutes]);
        }

        return result.toString();
    }

   
    public String printResult() {
        System.out.println(colClockData.getResult());
		return colClockData.getResult();
    }
}