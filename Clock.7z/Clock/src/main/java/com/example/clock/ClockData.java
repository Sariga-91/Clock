package com.example.clock;

public class ClockData {

	 public int hours;
	 public  int minutes;
	 public String result;
	    
	    

	    public int getHours() {
	        return hours;
	    }

	    public int getMinutes() {
	        return minutes;
	    }

	    public String getResult() {
	        return result;
	    }

	    public void setResult(String result) {
	        this.result = result;
	    }

}

