package com.example.clock;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ClockExceptionController {
   @ExceptionHandler(value = TimeNotfoundException.class)
   
   public ResponseEntity<Object> exception(TimeNotfoundException exception) {
	   
      return new ResponseEntity<>("Incorrect Time Format ", HttpStatus.NOT_FOUND);
      
   }
}